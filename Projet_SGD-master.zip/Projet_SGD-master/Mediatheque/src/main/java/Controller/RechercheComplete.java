/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.BDD;
import com.mongodb.BasicDBObject;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JTextField;

/**
 *
 * @author cb653705
 */
public class RechercheComplete implements ActionListener {
    JTextField prixMin;
    JTextField prixMax;
    JComboBox plateforme;
    JComboBox genre;
    CreationVisualisation ALV;
    BDD mongo;
    
    
    public RechercheComplete(JComboBox genre, JComboBox plateforme, JTextField prixMin, JTextField prixMax, CreationVisualisation alv, BDD mo){
        this.genre = genre;
        this.plateforme = plateforme;
        this.prixMax = prixMax;
        this.prixMin = prixMin;
        ALV = alv;
        mongo = mo;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        BasicDBObject query = new BasicDBObject();

        List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
        if(!genre.getSelectedItem().equals("GENRE"))
            obj.add(new BasicDBObject("genre", (String)genre.getSelectedItem()));
        if(!plateforme.getSelectedItem().equals("PLATEFORME"))
            obj.add(new BasicDBObject("plateforme", (String)plateforme.getSelectedItem()));
        
        int prixMini;
        try{
             prixMini= Integer.parseInt(prixMin.getText());
        }
        catch(Exception exc){
            prixMini = 0;
        }
        
        int prixMaxi;
        try{
             prixMaxi= Integer.parseInt(prixMax.getText());
        }
        catch(Exception exc){
            prixMaxi = 1999999999;
        }
        
        obj.add(new BasicDBObject("prix", new BasicDBObject("$gte", prixMini).append("$lte", prixMaxi)));
        query.put("$and", obj);
        
        ALV.setQuery(query);
            
    }
}
