/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author mg015362
 */
public class AjoutListeVisualisation {
    private JPanel liste;
    
    public AjoutListeVisualisation(JPanel liste){
        this.liste = liste;
        
    }
    
    public void addElement(String plateformeString, String nomJeu, String categorieJeu, String noteJeu){
        JPanel jp = new JPanel();
        jp.setLayout(new java.awt.BorderLayout());
        jp.setPreferredSize(new Dimension(liste.getWidth()-15, 100));
        jp.setMaximumSize(new Dimension(liste.getWidth()-15, 100));
        jp.setMinimumSize(new Dimension(liste.getWidth()-15, 100));
        
        JPanel image = new JPanel();
        jp.add(image, java.awt.BorderLayout.WEST);
        image.add(new JLabel("IMAGE ICI"));
        
        
        JButton detail = new JButton();
        detail.setText("Détails");
        jp.add(detail, java.awt.BorderLayout.EAST);
        
        JLabel plateformes = new JLabel();
        plateformes.setText(plateformeString);
        JLabel nom = new JLabel(nomJeu);
        JLabel categorie = new JLabel(categorieJeu);
        JLabel note = new JLabel(noteJeu);
        
        JPanel center = new JPanel();
        center.setLayout(new java.awt.GridLayout(4, 1));
        JPanel ligne1 = new JPanel();
        ligne1.setLayout(new java.awt.GridLayout(1, 3));
        ligne1.add(nom);
        ligne1.add(note);
        ligne1.add(categorie);
        
        center.add(ligne1);
        center.add(plateformes);
        jp.add(center, java.awt.BorderLayout.CENTER); 
        
        liste.add(jp);
       
    }
}
