/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.BDD;
import Model.Jeu;
import Model.Utilisateur;
import View.Note;
import com.mongodb.BasicDBObject;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import org.bson.BasicBSONObject;

/**
 *
 * @author cb653705
 */
public class Noter implements ActionListener{
    private BDD mongo;
    private JTextField note;
    private JTextArea commentaire;
    private Utilisateur user;
    private boolean exists;
    private int indiceCom;
    private Jeu jeu;
    private Note dialog;
    private CreationVisualisation CV;
    private DetailButton DB;
    public Noter(BDD mo, JTextField note, JTextArea com, boolean exists, int indice, Jeu j, Note dial, CreationVisualisation CV, DetailButton DB){
        mongo = mo;
        this.note = note;
        commentaire = com;
        user = ControleurConnexion.user;
        this.exists = exists;
        indiceCom = indice;
        jeu = j;
        dialog = dial;
        this.CV = CV;
        this.DB = DB;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        float noteValue;
        String comString;
        try{
            noteValue = Float.parseFloat(note.getText());
        }
        catch(Exception exc){
            JOptionPane jop = new JOptionPane();
            jop.showMessageDialog(null,"La note entrée n'est pas au bon format.","Erreur",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(noteValue < 0 || noteValue > 5){
            JOptionPane jop = new JOptionPane();
            jop.showMessageDialog(null,"La note entrée doit être entre 0 et 5.","Erreur",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        comString = commentaire.getText();

        if (exists)
        {
            mongo.setCollection("utilisateurs");
            mongo.getCollection().updateOne(
                    new BasicDBObject("pseudo", user.getPseudo()), 
                    new BasicDBObject("$set", new BasicDBObject("avis."+indiceCom+".note", noteValue))
            );
            mongo.getCollection().updateOne(
                    new BasicDBObject("pseudo", user.getPseudo()), 
                    new BasicDBObject("$set", new BasicDBObject("avis."+indiceCom+".commentaire", comString))
            );
        }
        else{
            
            mongo.setCollection("utilisateurs");
            if (user.getAvis().size() == 0)
            mongo.getCollection().updateOne(
                    new BasicDBObject("pseudo", user.getPseudo()), 
                    new BasicDBObject("$set", new BasicDBObject("avis", new ArrayList())));
                
            
            BasicDBObject toAdd = new BasicDBObject("$addToSet", 
                        new BasicDBObject("avis", 
                                new BasicDBObject()
                                        .append("note", noteValue)
                                        .append("jeu", jeu.getId())
                                        .append("commentaire", comString)
                        )
                    );
            System.out.println(toAdd);
            mongo.getCollection().updateOne(
                    new BasicDBObject("pseudo", user.getPseudo()), 
                    toAdd
            );
        }
        
        CV.reload();
        dialog.setVisible(false);
        DB.reload();
    }
    
}
