/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.Document;

/**
 *
 * @author valentin
 */
public class BDD {
    MongoClient mongo;
    MongoCollection<Document> collection;
    MongoDatabase db;
    
    public BDD(String s, String c)
    {
        
        char [ ] pass = new char[10];pass = s.toCharArray();
        MongoCredential credential = MongoCredential.createCredential(s, s, pass);
        MongoClient client = new MongoClient(new ServerAddress("mongo", 27017), Arrays.asList(credential));
        db = client.getDatabase(s);
        
    }
    
    public MongoCollection<Document> getCollection() {return collection;}
    public void setCollection(String col){ collection = db.getCollection(col);}
    
}
