package Model;

import Controller.ControleurConnexion;
import View.*;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.client.MongoDatabase;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.management.Query;
import javax.swing.JFrame;
import java.util.*;
import static java.util.Arrays.asList;
/**
 * Hello world!
 *
 */
public class Main 
{
    public static void main( String[] args ) throws UnknownHostException
    {
        //essayer de se connecter à partir de la fac pour voir
       /* try{
            MongoClientURI monclient = new MongoClientURI("mongodb://host1:vn934281@depinfo.u-bourgogne.fr");
            MongoClient mongo = new MongoClient(monclient);
            DB db = mongo.getDB("vn934281");
            DBCollection collection = db.getCollection("users");
            BasicDBObject query = new BasicDBObject();
            query.put("name", Pattern.compile("Bruce Lee"));
            DBCursor cursor = collection.find(query);
            DBObject obj  = cursor.next();
            Utilisateur u = new Utilisateur(obj);
            System.out.println(u.getPseudo()+ " "+ u.getMdp()+ " "+ u.getAdmin());
        } catch (UnknownHostException ex) {
            System.out.println(ex);
        }
        */
        // ça, ça marche ! mais il vous faut une base mongo en localhost avec une collection users remplie
        
        String client = "cb653705";
        String collection = "utilisateurs";
        BDD bdd = new BDD(client, collection);
        Connexion con = new Connexion();
//        Visualisation con = new Visualisation(new JFrame(), true, 0);
        ControleurConnexion control = new ControleurConnexion(bdd, con);
        con.addControleur(control);
        con.setVisible(true);
        
        
//        Connexion con = new Connexion();
////        Visualisation con = new Visualisation(new JFrame(), true, 0);
//        ControleurConnexion control = new ControleurConnexion(bdd, con);
//        con.addControleur(control);
//        con.setVisible(true);
    }
}
