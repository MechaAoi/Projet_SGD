/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.BDD;
import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import org.bson.Document;

/**
 *
 * @author cb653705
 */
public class RechercheGlobale implements ActionListener {
    JTextField JTA;
    CreationVisualisation ALV;
    BDD mongo;
    
    
    public RechercheGlobale(JTextField ja, CreationVisualisation alv, BDD mo){
        JTA = ja;
        ALV = alv;
        mongo = mo;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String a_chercher = JTA.getText();
        BasicDBObject query = new BasicDBObject();

        List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
        obj.add(new BasicDBObject("titre", new BasicDBObject("$regex", a_chercher).append("$options", "i")));
        obj.add(new BasicDBObject("editeur", new BasicDBObject("$regex", a_chercher).append("$options", "i")));
        obj.add(new BasicDBObject("genre", new BasicDBObject("$regex", a_chercher).append("$options", "i")));
        obj.add(new BasicDBObject("plateforme", new BasicDBObject("$regex", a_chercher).append("$options", "i")));
        obj.add(new BasicDBObject("serie", new BasicDBObject("$regex", a_chercher).append("$options", "i")));
        obj.add(new BasicDBObject("description", new BasicDBObject("$regex", a_chercher).append("$options", "i")));
        query.put("$or", obj);
        
        ALV.setQuery(query);
            
    }
    
}
