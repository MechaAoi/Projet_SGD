/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Avis;
import Model.BDD;
import Model.Jeu;
import Model.Utilisateur;
import View.Detail;
import View.Note;
import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import org.bson.Document;

/**
 *
 * @author cb653705
 */
public class DetailButton implements ActionListener {
    private Jeu jeu;
    private Detail detail;
    private BDD mongo;
    private CreationVisualisation CV;
    
    public DetailButton(Jeu j, Detail d, BDD mo, CreationVisualisation CV){
        jeu = j;
        detail = d;
        mongo = mo;
        this.CV = CV;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Note n = new Note(null, true);
        
        detail.getNoterButton().addActionListener(new RemplirNote(mongo, jeu, n, CV, this ));
        
        detail.getAvisArea().setText(jeu.getAvis());
        
        detail.getTitreLabel().setText(jeu.getTitre());
        
        String description = "Genre : "+ jeu.getGenre();
        description += "\nEditeur : "+ jeu.getEditeur();
        description += "\nDate de parution : "+ jeu.getDateParution();
        description += "\nPlateforme : "+ jeu.getPlateformeString();
        description += "\nPrix : "+ jeu.getPrix();
        description += "\nDisponibilité : "+ jeu.getDisponibilite();
        description += "\nSerie : "+ jeu.getSerie();
        description += "\n\nDescrition : "+jeu.getDescription();
        detail.getDescriptionArea().setText(description);
        
        detail.getNoteLabel().setText(jeu.getNote()+" / 5");
        
        detail.setVisible(true);
    }
    
    public void reload(){
        mongo.setCollection("jeux");
        Document doc = mongo.getCollection().find(new BasicDBObject("_id", jeu.getId())).iterator().next();
        String avis = "";
        BasicDBObject avisQuery = new BasicDBObject();
        avisQuery.put("avis.jeu", doc.get("_id"));
        
        mongo.setCollection("utilisateurs");
        MongoCursor<Document> users = mongo.getCollection().find(avisQuery).iterator();
        Document user;
        double note = 0;
        double nbNotes = 0;
        while(users.hasNext()){
            user = users.next();
            Utilisateur u = new Utilisateur(user);
            List<Avis> avisList = u.getAvis();
            for (int i = 0; i < avisList.size(); i++) {
                if (avisList.get(i).getJeu() == (Double) doc.get("_id")){
                    avis += u.getPseudo() + " : " + avisList.get(i).getNote() +" / 5 \n" + avisList.get(i).getCommentaire() + "\n\n";
                    note += avisList.get(i).getNote();
                    nbNotes++;
                }
            }
        }
        double noteFinale = note / nbNotes;
        System.out.println("AVIS : "+avis);
        System.out.println("noteFinale : "+noteFinale);
        jeu = new Jeu(doc, avis, noteFinale);

        
        detail.getAvisArea().setText(jeu.getAvis());
        
        detail.getTitreLabel().setText(jeu.getTitre());
        
        String description = "Genre : "+ jeu.getGenre();
        description += "\nEditeur : "+ jeu.getEditeur();
        description += "\nDate de parution : "+ jeu.getDateParution();
        description += "\nPlateforme : "+ jeu.getPlateformeString();
        description += "\nPrix : "+ jeu.getPrix();
        description += "\nDisponibilité : "+ jeu.getDisponibilite();
        description += "\nSerie : "+ jeu.getSerie();
        description += "\n\nDescrition : "+jeu.getDescription();
        detail.getDescriptionArea().setText(description);
        
        detail.getNoteLabel().setText(jeu.getNote()+" / 5");
        
    }
    
}
