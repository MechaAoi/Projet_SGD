/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.BDD;
import Model.Utilisateur;
import View.Connexion;
import View.Insertion;
import View.Visualisation;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MapReduceCommand;
import com.mongodb.MapReduceOutput;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import org.bson.Document;

/**
 *
 * @author vn934281
 */
public class ControleurConnexion implements ActionListener {
    //on cree les vues dont on aura besoin
    private Connexion con;
    private Visualisation vis;
    private Insertion insert;
    //on a besoin de savoir dans quelle base de données on travaille
    private BDD mongo;
    //utilisateur cree lors de la connexion
    public static Utilisateur user;
    // connexion -> 0   Visualisation -> 1
    private int vue;
    
    //constructeur pour relier la bdd et la vue connexion
    public ControleurConnexion(BDD m, Connexion c)
    {
        con = c;
        mongo = m;
        vue = 0;
    }
    //constructeur pour relier la bdd et la vue Visualisation
    public ControleurConnexion(BDD m, Visualisation v)
    {
        vis = v;
        mongo = m;
        vue = 1;
    }
    public ControleurConnexion(BDD m, Insertion i)
    {
        insert = i;
        mongo = m;
        vue = 2;
    }
    //mega méthode de la mort qui tue
    @Override
    public void actionPerformed(ActionEvent e) {
        boolean existe = false;
        //on recupere le nom du boutton qui a été cliqué
        Object comp = e.getSource();
        JButton b = null;
        JMenuItem m = null;
        if( comp instanceof JButton ){
        b = (JButton)comp;
        }
        else if ( comp instanceof JMenuItem)
        {
        m = (JMenuItem) comp ;
        }
        //si la vue actuelle est celle de la connexion
        if (vue == 0)
        {
            mongo.setCollection("utilisateurs");
            //si l'utilisateur veut s'inscrire, on vérifie que tous les champs soient remplis
            if(b.getName().equals("inscription") && !con.getPseudo().equals("") && !con.getMdp().equals(""))
            {
                try{
                //on recherche dans la base de donnée si un pseudo identique existe deja
                Document query = new Document();
                query.put("pseudo", Pattern.compile(con.getPseudo()));
                MongoCursor<Document> cursor = mongo.getCollection().find(query).iterator();
                Document obj  = cursor.next();
                existe = true;
                }catch(Exception ex)
                { existe = false;}
                //si il existe, on affiche un message d'erreur
                if( existe == true )
                {
                    JOptionPane jop = new JOptionPane();
                    jop.showMessageDialog(con,"Pseudo déjà utilisé","Information",JOptionPane.INFORMATION_MESSAGE);
                }
                //sinon on insère dans la base de données
                else
                {
                Document inscr = new Document().append("pseudo", con.getPseudo()).append("mdp", con.getMdp());
                
               
                mongo.getCollection().insertOne(inscr);
                }

            }
            //connexion , on vérifie que tous les champs soient remplis
            else if(b.getName().equals("connexion") && !con.getPseudo().equals("") && !con.getMdp().equals("") )
            {
                String pseudo = con.getPseudo();
                String mdp = con.getMdp();
                try{
                //on recherche dans la base de donnée si l'utilisateur existe
                BasicDBObject query = new BasicDBObject();
                List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
                obj.add(new BasicDBObject("pseudo", pseudo));
                obj.add(new BasicDBObject("mdp", mdp));
                query.put("$and",obj);
                MongoCursor<Document> cursor = mongo.getCollection().find(query).iterator();
                Document dbobject  = cursor.next();
                
                //si il existe, on cree un utilisateur représentant le client connecté
                existe = true;
                user = new Utilisateur(dbobject);
                }catch(Exception ex)
                { existe = false;}
                //on se connecte
                if( existe == true)
                {
                    JPanel jpan = new JPanel();
                    jpan.setLayout(new javax.swing.BoxLayout(jpan, javax.swing.BoxLayout.PAGE_AXIS));
                    //on crée une nouvelle instance de la vue principale
                    vis = new Visualisation(con,true,user.getAdmin(), jpan); 
                    int width = vis.getListeWidth();
                    CreationVisualisation ALV = new CreationVisualisation(vis.getGenre(),vis.getPlateforme(), jpan, width, mongo, vis.getComboBoxTri());
                    TriJeux TJ = new TriJeux(ALV);
                    vis.getComboBoxTri().addActionListener(TJ);
                    
                    vis.getRechGlobale().addActionListener(new RechercheGlobale(vis.getRechGlobTextField(), ALV, mongo));
                    
                    vis.getRechComplete().addActionListener(new RechercheComplete(vis.getGenre(),vis.getPlateforme(),vis.getPrixMin(),vis.getPrixMax(), ALV, mongo));
                    //on lui associe un controleur
                    ControleurConnexion control2 = new ControleurConnexion(mongo,vis);
                    vis.addControleur(control2);
                    //on définit la vue courante comme étant la Visualisation
                    vue = 1;
                    con.setVisible(false);
                    vis.setVisible(true);
                }
                //erreur, soit l'utilisateur n'xiste pas , soit erreur dans l'entree des identifiants
                else
                {
                    JOptionPane jop = new JOptionPane();
                    jop.showMessageDialog(con,"Pseudo ou mot de passe incorrect, enregistrez vous ?","Erreur",JOptionPane.INFORMATION_MESSAGE);
                }        

            }
            //si tous les champs n'ont pas été remplis
            else 
            {
                JOptionPane jop = new JOptionPane();
                jop.showMessageDialog(con,"Veuillez remplir tous les champs","Information",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        //si la vue courante est la visualisation
        if( vue == 1)
        {
            //on gere la deconnexion
            if(b!= null)
            {
                if (b.getName().equals("deconnexion"))
                {
                    //on redefinit la vue courante comme etant l'ecran de connexion
                    vue = 0;
                    //on recree une vue et on lui associe un controleur
                    con = new Connexion();
                    ControleurConnexion control = new ControleurConnexion(mongo, con);
                    con.addControleur(control);
                    vis.setVisible(false);
                    con.setVisible(true);
                }
            }
            if(m!= null)
            {
                if (m.getName().equals("insertion"))
                {
                   
                    insert = new Insertion(vis,true);
                    ControleurConnexion control2 = new ControleurConnexion(mongo, insert);
                    insert.addControleur(control2);
                  //  vis.setVisible(false);
                    insert.setVisible(true);
                    
                }
            }
        }
        if ( vue == 2)
        {
            if ( b.getName().equals("valider"))
            {
                mongo.setCollection("jeux");
                //faire une requete pour trouver l'id maximum
                BasicDBObject query = new BasicDBObject();
                query.put("_id", -1);
                Document doc = mongo.getCollection().find().sort(query).limit(1).first();
                Double id = (Double) doc.get("_id");
                //System.out.println(doc.get("_id"));
                Calendar now = Calendar.getInstance();
                int annee = now.get(Calendar.YEAR);
                int mois = now.get(Calendar.MONTH)+1;
                int jour = now.get(Calendar.DATE);
                Double prix = Double.parseDouble(insert.getPrix());
                String date = Integer.toString(jour) + "/"+Integer.toString(mois)+"/"+Integer.toString(annee);
                Document newGame = new Document().append("_id", id+ 1)
                                                 .append("titre", insert.getTitre())
                                                 .append("date_parution", insert.getDate())
                                                 .append("date_ajout", date)
                                                 .append("editeur", insert.getEditeur())
                                                 .append("genre", insert.getGenre())
                                                 .append("prix", prix)
                                                 .append("disponibilite", insert.getDisponibilite())
                                                 .append("serie", insert.getSerie())
                                                 .append("description", insert.getDescription());
                mongo.getCollection().insertOne(newGame);
                insert.setVisible(false);
                 CreationVisualisation ALV = new CreationVisualisation();
                    ALV.reload();
                vis.setVisible(true);
                
            }
        }
        
    }
    
}
