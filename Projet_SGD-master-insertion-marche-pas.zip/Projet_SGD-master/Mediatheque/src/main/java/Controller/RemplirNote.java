/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Avis;
import Model.BDD;
import Model.Jeu;
import Model.Utilisateur;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author cb653705
 */
public class RemplirNote implements ActionListener{
    private BDD mongo;
    private Utilisateur user;
    private Jeu jeu;
    private boolean exists;
    private View.Note dialog;
    public boolean getExists(){
        return exists;
    }
    
    public RemplirNote(BDD mongo, Jeu j, View.Note dial, CreationVisualisation CV, DetailButton DB){
        dialog = dial;
        this.mongo = mongo;
        user = ControleurConnexion.user;
        jeu = j;
        exists = false;
        int indice  =-1;
        ArrayList<Avis> avis = user.getAvis();
        for (int i = 0; i < avis.size(); i++) {
            if(avis.get(i).getJeu() == jeu.getId())
            {
                dialog.getNoteField().setText(avis.get(i).getNote()+"");
                dialog.getComArea().setText(avis.get(i).getCommentaire()+"");
                indice = i;
                exists = true;
                break;
            }
        }
        dialog.getValidate().addActionListener(new Noter(mongo, dialog.getNoteField(), dialog.getComArea(), exists, indice, jeu, dialog, CV, DB));
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        dialog.setVisible(true);
    }
    
    
    
}
