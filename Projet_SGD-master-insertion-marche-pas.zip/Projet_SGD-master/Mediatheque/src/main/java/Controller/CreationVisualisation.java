/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import Model.Avis;
import Model.BDD;
import Model.Jeu;
import Model.Utilisateur;
import View.Detail;
import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Projections;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import org.bson.Document;

/**
 *
 * @author mg015362
 */
public class CreationVisualisation {
    private JPanel liste;
    private int width;
    private BDD mongo;
    private JComboBox choixTri;
    private ArrayList<Jeu> jeux;
    private JComboBox genre;
    private JComboBox plateforme;
    private BasicDBObject query;
            
    public CreationVisualisation(JComboBox genre,JComboBox plateforme, JPanel liste, int width, BDD mongo, JComboBox JCB){
        this.liste = liste;
        this.width = width-20;
        this.mongo = mongo;
        this.choixTri = JCB;
        this.plateforme = plateforme;
        this.genre = genre;
        initComboBox();
        query = new BasicDBObject();
        setQuery(query);
        
    }
    public CreationVisualisation(){}
    
    public void reload(){
        setQuery(query);
    }
    
    
    public void setQuery(BasicDBObject q)
    {
        this.query = q;
        jeux = new ArrayList<>();
        mongo.setCollection("jeux");
        MongoCursor<Document> cursor = mongo.getCollection().find(q).iterator();
        Document doc;        
        mongo.setCollection("utilisateurs");
        while(cursor.hasNext())
        {
            doc = cursor.next();
            String avis = "";
            BasicDBObject avisQuery = new BasicDBObject();
            avisQuery.put("avis.jeu", doc.get("_id"));
            MongoCursor<Document> users = mongo.getCollection().find(avisQuery).iterator();
            Document user;
            double note = 0;
            double nbNotes = 0;
            while(users.hasNext()){
                user = users.next();
                Utilisateur u = new Utilisateur(user);
                List<Avis> avisList = u.getAvis();
                for (int i = 0; i < avisList.size(); i++) {
                    if (avisList.get(i).getJeu() == (Double) doc.get("_id")){
                        avis += u.getPseudo() + " : " + avisList.get(i).getNote() +" / 5 \n" + avisList.get(i).getCommentaire() + "\n\n";
                        note += avisList.get(i).getNote();
                        nbNotes++;
                    }
                }
            }
            double noteFinale = note / nbNotes;
            
            Jeu j = new Jeu(doc, avis, noteFinale);
            jeux.add(j);
        }
        sort();
                
    }
    
    public void sort(){
        liste.removeAll();
        if (choixTri.getSelectedItem().equals("Note")) {
            Comparator c = new Comparator(){
                @Override
                public int compare(Object o1, Object o2) {
                    Jeu j1 = (Jeu)o1;
                    Jeu j2 = (Jeu)o2;
                    return (int)Math.ceil(j1.getNote() - j2.getNote());
                }
            };
            jeux.sort(c);
        }
        if (choixTri.getSelectedItem().equals("Nom")) {
            Comparator c = new Comparator(){
                @Override
                public int compare(Object o1, Object o2) {
                    Jeu j1 = (Jeu)o1;
                    Jeu j2 = (Jeu)o2;
                    return j1.getTitre().compareTo(j2.getTitre());
                }
            };
            jeux.sort(c);
        }
        if (choixTri.getSelectedItem().equals("Date de parution")) {
            Comparator c = new Comparator(){
                @Override
                public int compare(Object o1, Object o2) {
                    Jeu j1 = (Jeu)o1;
                    Jeu j2 = (Jeu)o2;
                    
                    return dateToNbJour(j2.getDateParution()) - dateToNbJour(j1.getDateParution());
                }
            };
            jeux.sort(c);
        }
        
        for (int i = 0; i < jeux.size(); i++) {
           addElement(jeux.get(i));
        }
        
        liste.revalidate();
        liste.revalidate();
        liste.repaint();
        liste.repaint();
    }
    
    private int dateToNbJour(String date){
        String s[] = date.split("/");
        return Integer.parseInt(s[0]) + Integer.parseInt(s[1]) * 31 + Integer.parseInt(s[2]) * 365;
    }
    
    
    public void addElement(Jeu j){
        JPanel jp = new JPanel();
        jp.setLayout(new java.awt.BorderLayout());
        jp.setPreferredSize(new Dimension(width, 100));
        jp.setMaximumSize(new Dimension(width, 100));
        jp.setMinimumSize(new Dimension(width, 100));
        JPanel image = new JPanel();
        jp.add(image, java.awt.BorderLayout.WEST);
        image.add(new JLabel("IMAGE ICI"));
        
        
        JButton detail = new JButton();
        detail.setText("Détails");
        jp.add(detail, java.awt.BorderLayout.EAST);
        detail.addActionListener(new DetailButton(j, new Detail(null, true), mongo, this));
        
        
        JLabel plateformes = new JLabel();
        plateformes.setText("Plateforme : "+j.getPlateformeString());
        JLabel nom = new JLabel("Titre : " + j.getTitre());
        JLabel categorie = new JLabel("Genre : " + j.getGenre());
        JLabel note = new JLabel("Note : "+j.getNote());
        
        JPanel center = new JPanel();
        center.setLayout(new java.awt.GridLayout(4, 1));
        JPanel ligne1 = new JPanel();
        ligne1.setLayout(new java.awt.GridLayout(1, 3));
        ligne1.add(nom);
        ligne1.add(note);
        ligne1.add(categorie);
        
        center.add(ligne1);
        center.add(plateformes);
        jp.add(center, java.awt.BorderLayout.CENTER); 
        
        liste.add(jp);
    }

    private void initComboBox() {
        Block<Document> addToCombo = new Block<Document>() {
            @Override
            public void apply(final Document document) {
                plateforme.addItem(document.getString("_id"));
            }
        };
        
        mongo.setCollection("jeux");
        mongo.getCollection().aggregate(Arrays.asList(
                Aggregates.unwind("$plateforme"),
                Aggregates.group("$plateforme")
        )).forEach(addToCombo);
        
        addToCombo = new Block<Document>() {
            @Override
            public void apply(final Document document) {
                genre.addItem(document.getString("_id"));
            }
        };
        
        mongo.getCollection().aggregate(Arrays.asList(
                Aggregates.group("$genre")
        )).forEach(addToCombo);
        
    }
}
