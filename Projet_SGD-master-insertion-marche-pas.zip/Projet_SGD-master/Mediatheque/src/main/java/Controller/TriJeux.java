/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;

/**
 *
 * @author cb653705
 */
public class TriJeux implements ActionListener{

    private CreationVisualisation ALV;
            
    
    public TriJeux(CreationVisualisation alv){
        this.ALV = alv;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        JComboBox jC = (JComboBox) e.getSource();
        jC.removeItemAt(0);
        ALV.sort();
    }
    
}
