package Model;

import org.bson.Document;

public class Avis
{
	private double note;
	private double jeu;
	private String commentaire;

	public Avis(Document obj)
	{
		note 		= (Double) obj.get("note");
		jeu 		= (Double) obj.get("jeu");
		commentaire = (String) obj.get("commentaire");
	}

	public Avis(double _note, double _jeu, String _commentaire)
	{
		note 		= _note;
		jeu 		= _jeu;
		commentaire = _commentaire;
	}
        
        public double getJeu(){    return jeu; }
        public double getNote(){    return note; }
        public String getCommentaire(){    return commentaire; }
}