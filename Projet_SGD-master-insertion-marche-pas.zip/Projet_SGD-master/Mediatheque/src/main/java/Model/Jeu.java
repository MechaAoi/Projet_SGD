package Model;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

public class Jeu 
{
  private double id;
  private String titre;
  private String date_parution;
  private String date_ajout;
  private String editeur;
  private String genre;
  private ArrayList plateforme;
  private double prix;
  private double note;
  private double nbNote;
  private String disponibilite;
  private String serie;
  private String description;
  private String image;
  private String avis;

  public Jeu(Document obj, String _avis, double _note)
  {
    id            = (Double) obj.get("_id");
    titre         = (String) obj.get("titre");
    date_parution = (String) obj.get("date_parution");
    date_ajout    = (String) obj.get("date_ajout");
    editeur       = (String) obj.get("editeur");
    genre         = (String) obj.get("genre");
    prix          = (Double) obj.get("prix");
    note          = _note;
    nbNote        = (Double) obj.get("nbNote");
    disponibilite = (String) obj.get("disponibilite");
    serie         = (String) obj.get("serie");
    description   = (String) obj.get("description");
    image         = (String) obj.get("image");
    plateforme    =  (ArrayList) obj.get("plateforme");
    avis          = _avis;
//Ici, il doit y avoir moyen de faire un split de la chaine pour récupérer les plateformes unes à unes
  }

  public Jeu(double _id, String _titre, String _parution, String _ajout, String _editeur, String _genre, ArrayList _plateforme, double _prix, double _note, double _nbNote, String _disponibilite, String _serie, String _description, String _image, String _avis)
  {
    id            = _id;
    titre         = _titre;
    date_parution = _parution;
    date_ajout    = _ajout;
    editeur       = _editeur;
    genre         = _genre;
    plateforme    = _plateforme;
    prix          = _prix;
    note          = _note;
    nbNote        = _nbNote;
    disponibilite = _disponibilite;
    serie         = _serie;
    description   = _description;
    image         = _image;
    avis          = _avis;
  }

  // Getter
  public String getAvis() { return avis; }
  public double getId() { return id; }
  public String getTitre() { return titre; }
  public String getDateParution() { return date_parution; }
  public String getDateAjout() { return date_ajout; }
  public String getEditeur() { return editeur; }
  public String getGenre() { return genre ;}
  public ArrayList getPlateforme() { return plateforme; }
  public String getPlateformeString() 
  {
      String str = "";
      for (int i = 0; i < plateforme.size(); i++) {
          str += (String)plateforme.get(i) ;
          if (i+1 < plateforme.size())
              str += ", ";
      }
      return str;
  }
  public double getPrix() { return prix; }
  public double getNote() { return note; }
  public double getnbNote() { return nbNote; }
  public String getDisponibilite() { return disponibilite; }
  public String getSerie() { return serie; }
  public String getDescription() { return description; }
  public String getImage() { return image; }
  public void addAvis(String pseudo, float note, String commentaire){
      avis += pseudo + " : " + note +" / 5 \n" + commentaire + "\n\n";
      this.note = (this.note * nbNote) + note;
      nbNote++;
      this.note /= nbNote;
      
  }
  
  
  // Setter
  public void setDisponibilite(String _disponibilite) { disponibilite = _disponibilite; }
  public void setDescription(String _description) { description = _description; }

}